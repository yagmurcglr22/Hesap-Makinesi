﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculatorcs
{
    public partial class Form1 : Form
    {
        string lastUsedOperator;
        string lastOperation;
        bool reset;

        public Form1()
        {
            InitializeComponent();
        }

        private void Islem_Click(object sender, EventArgs e)
        {
            

            var btn = (Button)sender;

            if (btn.Text == "C")
            {
                
                GirisLbl.Text = "0";
                lastOperation = "";
                lastUsedOperator = "";
                IslemLabel.Text = "0";
            }

            if (btn.Text == "CE")
            {
                GirisLbl.Text = GirisLbl.Text.Remove(GirisLbl.Text.Length - 1);
            }

            if (
                btn.Text != "CE"
                && btn.Text != "C"
                && btn.Text != "="
                && btn.Text != "."
                && btn.Text != "X^2"
                && btn.Text != "√X"
            )
            {
                reset = false;
                if (IslemLabel.Text == "0")
                {
                    IslemLabel.Text = GirisLbl.Text;
                }
                else
                {
                    if (lastUsedOperator != "")
                    {
                        IslemLabel.Text += lastUsedOperator + GirisLbl.Text;
                    }
                    else
                    {
                        IslemLabel.Text += btn.Text + GirisLbl.Text;
                    }
                }
                GirisLbl.Text = "0";
                lastUsedOperator = btn.Text;
            }

            if (btn.Text == "=")
            {
                string islem = IslemLabel.Text + lastUsedOperator + GirisLbl.Text;

                if (lastUsedOperator != "")
                {
                    lastOperation = lastUsedOperator + GirisLbl.Text;
                }

                var operationB = new DataTable().Compute(islem, "");

                var operationA = new DataTable().Compute(GirisLbl.Text + lastOperation, "");

                if (IslemLabel.Text == "0" && operationA.ToString() != "")
                {
                    GirisLbl.Text = operationA.ToString();
                }
                else
                {
                    GirisLbl.Text = operationB.ToString();
                }

                IslemLabel.Text = "0";
                lastUsedOperator = "";
                reset = true;

            }

            if(btn.Text == "X^2")
            {
                double sayi = double.Parse(GirisLbl.Text);
                sayi = Math.Pow(sayi, 2d);
                GirisLbl.Text = sayi.ToString();
            }

            if (btn.Text == "√X")
            {
                double sayi = double.Parse(GirisLbl.Text);
                sayi = Math.Sqrt(sayi);
                GirisLbl.Text = sayi.ToString();
            }

            if(btn.Text == ".")
            {
                if(!GirisLbl.Text.Contains(btn.Text))
                {
                    GirisLbl.Text += ".";
                }


            }


        }

        private void Num_Click(object sender, EventArgs e)
        {
            var btn = (Button)sender;

            if (reset) 
            {
                IslemLabel.Text = "0";
                GirisLbl.Text = "0";
                lastOperation = "";
                lastUsedOperator = "";

                if ((btn.Text == "0" || btn.Text == "00") && GirisLbl.Text != "0")
                {
                    GirisLbl.Text = btn.Text;
                }

                if (btn.Text != "0" && btn.Text != "00")
                {
                    if (GirisLbl.Text == "0")
                    {
                        GirisLbl.Text = btn.Text;
                    }
                    else
                    {
                        GirisLbl.Text = btn.Text;
                    }
                }
                reset = false;
                return;
            }
            else
            {
                if ((btn.Text == "0" || btn.Text == "00") && GirisLbl.Text != "0")
                {
                    GirisLbl.Text += btn.Text;
                }

                if (btn.Text != "0" && btn.Text != "00")
                {
                    if (GirisLbl.Text == "0")
                    {
                        GirisLbl.Text = btn.Text;
                    }
                    else
                    {
                        GirisLbl.Text += btn.Text;
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e) { }

        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
        bool isDragging;
        Size offsetScreen;
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            offsetScreen = new Size(MousePosition.X - Location.X, MousePosition.Y - Location.Y);
            isDragging = true;
    
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Location = MousePosition - offsetScreen;
            }
        }
    }
}
